﻿namespace ServerClient
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPORT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtHOST = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCONNECT = new System.Windows.Forms.Button();
            this.txtMESSAGE = new System.Windows.Forms.TextBox();
            this.btnSEND = new System.Windows.Forms.Button();
            this.txtSTATUS = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtPORT
            // 
            this.txtPORT.Location = new System.Drawing.Point(249, 23);
            this.txtPORT.Name = "txtPORT";
            this.txtPORT.Size = new System.Drawing.Size(56, 22);
            this.txtPORT.TabIndex = 9;
            this.txtPORT.Text = "127.0.0.1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(192, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "PORT:";
            // 
            // txtHOST
            // 
            this.txtHOST.Location = new System.Drawing.Point(70, 24);
            this.txtHOST.Name = "txtHOST";
            this.txtHOST.Size = new System.Drawing.Size(100, 22);
            this.txtHOST.TabIndex = 7;
            this.txtHOST.Text = "127.0.0.1";
            this.txtHOST.TextChanged += new System.EventHandler(this.txtHOST_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "HOST:";
            // 
            // btnCONNECT
            // 
            this.btnCONNECT.Location = new System.Drawing.Point(321, 23);
            this.btnCONNECT.Name = "btnCONNECT";
            this.btnCONNECT.Size = new System.Drawing.Size(90, 23);
            this.btnCONNECT.TabIndex = 5;
            this.btnCONNECT.Text = "CONNECT";
            this.btnCONNECT.UseVisualStyleBackColor = true;
            this.btnCONNECT.Click += new System.EventHandler(this.btnCONNECT_Click);
            // 
            // txtMESSAGE
            // 
            this.txtMESSAGE.Location = new System.Drawing.Point(16, 129);
            this.txtMESSAGE.Multiline = true;
            this.txtMESSAGE.Name = "txtMESSAGE";
            this.txtMESSAGE.Size = new System.Drawing.Size(579, 63);
            this.txtMESSAGE.TabIndex = 10;
            this.txtMESSAGE.TextChanged += new System.EventHandler(this.txtMESSAGE_TextChanged);
            // 
            // btnSEND
            // 
            this.btnSEND.Location = new System.Drawing.Point(622, 129);
            this.btnSEND.Name = "btnSEND";
            this.btnSEND.Size = new System.Drawing.Size(90, 23);
            this.btnSEND.TabIndex = 11;
            this.btnSEND.Text = "SEND";
            this.btnSEND.UseVisualStyleBackColor = true;
            this.btnSEND.Click += new System.EventHandler(this.btnSEND_Click);
            // 
            // txtSTATUS
            // 
            this.txtSTATUS.Location = new System.Drawing.Point(16, 273);
            this.txtSTATUS.Multiline = true;
            this.txtSTATUS.Name = "txtSTATUS";
            this.txtSTATUS.Size = new System.Drawing.Size(579, 200);
            this.txtSTATUS.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 17);
            this.label3.TabIndex = 13;
            this.label3.Text = "INCOMING MESSAGE:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 17);
            this.label4.TabIndex = 14;
            this.label4.Text = "OUTCOMING MESSAGE:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(750, 525);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSTATUS);
            this.Controls.Add(this.btnSEND);
            this.Controls.Add(this.txtMESSAGE);
            this.Controls.Add(this.txtPORT);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtHOST);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCONNECT);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CLIENT";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPORT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtHOST;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCONNECT;
        private System.Windows.Forms.TextBox txtMESSAGE;
        private System.Windows.Forms.Button btnSEND;
        private System.Windows.Forms.TextBox txtSTATUS;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

