﻿namespace ServerClient
{
    partial class SERVER
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSTART = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtHOST = new System.Windows.Forms.TextBox();
            this.txtPORT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSTOP = new System.Windows.Forms.Button();
            this.txtSTATUS = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnSTART
            // 
            this.btnSTART.Location = new System.Drawing.Point(336, 39);
            this.btnSTART.Name = "btnSTART";
            this.btnSTART.Size = new System.Drawing.Size(75, 23);
            this.btnSTART.TabIndex = 0;
            this.btnSTART.Text = "START";
            this.btnSTART.UseVisualStyleBackColor = true;
            this.btnSTART.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "HOST:";
            // 
            // txtHOST
            // 
            this.txtHOST.Location = new System.Drawing.Point(85, 40);
            this.txtHOST.Name = "txtHOST";
            this.txtHOST.Size = new System.Drawing.Size(100, 22);
            this.txtHOST.TabIndex = 2;
            this.txtHOST.Text = "127.0.0.1";
            this.txtHOST.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtPORT
            // 
            this.txtPORT.Location = new System.Drawing.Point(264, 39);
            this.txtPORT.Name = "txtPORT";
            this.txtPORT.Size = new System.Drawing.Size(56, 22);
            this.txtPORT.TabIndex = 4;
            this.txtPORT.Text = "127.0.0.1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(207, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "PORT:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnSTOP
            // 
            this.btnSTOP.Location = new System.Drawing.Point(430, 39);
            this.btnSTOP.Name = "btnSTOP";
            this.btnSTOP.Size = new System.Drawing.Size(75, 23);
            this.btnSTOP.TabIndex = 5;
            this.btnSTOP.Text = "STOP";
            this.btnSTOP.UseVisualStyleBackColor = true;
            this.btnSTOP.Click += new System.EventHandler(this.btnSTOP_Click);
            // 
            // txtSTATUS
            // 
            this.txtSTATUS.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSTATUS.Location = new System.Drawing.Point(85, 86);
            this.txtSTATUS.Multiline = true;
            this.txtSTATUS.Name = "txtSTATUS";
            this.txtSTATUS.Size = new System.Drawing.Size(420, 214);
            this.txtSTATUS.TabIndex = 6;
            // 
            // SERVER
            // 
            this.AccessibleDescription = "";
            this.AccessibleName = "";
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 369);
            this.Controls.Add(this.txtSTATUS);
            this.Controls.Add(this.btnSTOP);
            this.Controls.Add(this.txtPORT);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtHOST);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSTART);
            this.Name = "SERVER";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SERVER";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSTART;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtHOST;
        private System.Windows.Forms.TextBox txtPORT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSTOP;
        private System.Windows.Forms.TextBox txtSTATUS;
    }
}

